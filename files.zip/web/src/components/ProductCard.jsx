import React from 'react';

export default function ProductCard({ product }) {
  return (
    <article className="bg-white dark:bg-slate-800 rounded-lg shadow-sm overflow-hidden">
      <img src={product.media?.[0] || '/placeholder.png'} alt={product.title} className="w-full h-44 object-cover" />
      <div className="p-3">
        <h3 className="text-sm font-semibold">{product.title}</h3>
        <p className="text-xs text-gray-500">{product.category}</p>
        <div className="mt-2 flex justify-between items-center">
          <div>
            <div className="text-base font-bold">₹{product.base_price}/day</div>
            <div className="text-xs text-gray-500">Deposit ₹{product.security_deposit}</div>
          </div>
          <button className="bg-indigo-600 text-white px-3 py-1 rounded">Rent</button>
        </div>
      </div>
    </article>
  );
}