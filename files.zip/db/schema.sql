-- Users & Auth
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  password_hash TEXT NOT NULL,
  name TEXT,
  kyc_document_url TEXT,
  is_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE roles (
  id SERIAL PRIMARY KEY,
  name TEXT UNIQUE NOT NULL
);

CREATE TABLE user_roles (
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  role_id INT REFERENCES roles(id),
  PRIMARY KEY (user_id, role_id)
);

-- Categories
CREATE TABLE categories (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  parent_id INT REFERENCES categories(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Products
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
  category_id INT REFERENCES categories(id),
  title TEXT NOT NULL,
  description TEXT,
  base_price NUMERIC(12,2) NOT NULL, -- per day
  weekly_price NUMERIC(12,2),
  monthly_price NUMERIC(12,2),
  security_deposit NUMERIC(12,2) DEFAULT 0,
  condition TEXT,
  location GEOGRAPHY(POINT, 4326),
  address JSONB,
  availability JSONB, -- optional calendar blobs (or separate table)
  status TEXT NOT NULL DEFAULT 'pending', -- pending/active/blocked
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE product_media (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID REFERENCES products(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  media_type TEXT, -- image/video/doc
  order_no INT DEFAULT 0
);

-- Rentals
CREATE TABLE rentals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID REFERENCES products(id),
  renter_id UUID REFERENCES users(id),
  owner_id UUID REFERENCES users(id),
  worker_id UUID REFERENCES users(id), -- assigned worker
  start_at TIMESTAMP WITH TIME ZONE,
  end_at TIMESTAMP WITH TIME ZONE,
  actual_return_at TIMESTAMP WITH TIME ZONE,
  daily_price NUMERIC(12,2),
  security_deposit NUMERIC(12,2),
  service_fee NUMERIC(12,2),
  commission NUMERIC(12,2),
  status TEXT, -- requested, accepted, picked_up, ongoing, returned, cancelled, disputed, completed
  late_fee NUMERIC(12,2),
  damage_fee NUMERIC(12,2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rental_id UUID REFERENCES rentals(id),
  payer_id UUID REFERENCES users(id),
  payee_id UUID REFERENCES users(id),
  amount NUMERIC(12,2),
  currency TEXT DEFAULT 'INR',
  status TEXT, -- pending, held, released, failed, refunded
  method TEXT, -- bank-transfer, UPI-offline, manual
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Wallets
CREATE TABLE wallets (
  user_id UUID PRIMARY KEY REFERENCES users(id),
  balance NUMERIC(14,2) DEFAULT 0,
  pending_balance NUMERIC(14,2) DEFAULT 0,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Reviews
CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  target_type TEXT, -- product/user/owner/worker
  target_id UUID,
  author_id UUID REFERENCES users(id),
  rating INT CHECK (rating BETWEEN 1 AND 5),
  text TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Disputes
CREATE TABLE disputes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rental_id UUID REFERENCES rentals(id),
  opened_by UUID REFERENCES users(id),
  reason TEXT,
  status TEXT DEFAULT 'open',
  resolution TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Notifications & Audit
CREATE TABLE notifications ( id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID REFERENCES users(id), type TEXT, payload JSONB, read BOOLEAN DEFAULT FALSE, created_at TIMESTAMP WITH TIME ZONE DEFAULT now());
CREATE TABLE audit_logs ( id UUID PRIMARY KEY DEFAULT gen_random_uuid(), actor_id UUID, action TEXT NOT NULL, resource_type TEXT, resource_id UUID, metadata JSONB, ip TEXT, user_agent TEXT, created_at TIMESTAMP WITH TIME ZONE DEFAULT now());