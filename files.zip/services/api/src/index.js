const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const bodyParser = require('body-parser');

const app = express();
app.use(helmet());
app.use(bodyParser.json());

// Postgres pool
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', apiLimiter);

// Simple RBAC middleware
function requireRole(required) {
  return (req, res, next) => {
    const auth = req.headers.authorization;
    if (!auth) return res.status(401).json({ success: false, error: { code: 2001, message: 'No token' }});
    const token = auth.split(' ')[1];
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      req.user = payload;
      if (!payload.roles || !payload.roles.includes(required)) {
        return res.status(403).json({ success: false, error: { code: 2002, message: 'Insufficient permissions' }});
      }
      next();
    } catch (err) {
      return res.status(401).json({ success: false, error: { code: 2001, message: 'Token invalid' }});
    }
  };
}

// Auth example
const bcrypt = require('bcrypt');
app.post('/api/v1/auth/register', async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password) return res.status(400).json({ success: false, error: { code: 1001, message: 'Missing fields' }});
  const password_hash = await bcrypt.hash(password, 12);
  const result = await pool.query('INSERT INTO users(email,name,password_hash) VALUES($1,$2,$3) RETURNING id', [email, name, password_hash]);
  return res.status(201).json({ success: true, data: { id: result.rows[0].id }});
});

app.post('/api/v1/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const r = await pool.query('SELECT id, password_hash FROM users WHERE email=$1', [email]);
  if (!r.rowCount) return res.status(401).json({ success: false, error: { code: 2001, message: 'Invalid credentials' }});
  const user = r.rows[0];
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ success: false, error: { code: 2001, message: 'Invalid credentials' }});
  // fetch roles
  const rolesRes = await pool.query('SELECT r.name FROM roles r JOIN user_roles ur ON ur.role_id=r.id WHERE ur.user_id=$1', [user.id]);
  const roles = rolesRes.rows.map(r => r.name);
  const payload = { sub: user.id, roles };
  const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '15m' });
  const refresh = jwt.sign({ sub: user.id }, process.env.JWT_REFRESH_SECRET, { expiresIn: '30d' });
  // store refresh token in DB or Redis (omitted here)
  res.json({ success: true, data: { accessToken: token, refreshToken: refresh }});
});

app.get('/api/v1/admin/analytics', requireRole('admin'), async (req, res) => {
  // stub analytics
  const usersCount = (await pool.query('SELECT count(*) FROM users')).rows[0].count;
  res.json({ success: true, data: { users: Number(usersCount) }});
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`API listening ${port}`));